import pandas as pd
import numpy as np
import re
import json
from pathlib import Path
from typing import Dict, Any

def _json_default(obj):
    """Handle numpy/pandas types for JSON serialization."""
    if isinstance(obj, (np.integer, np.int64, np.int32, np.int16, np.int8)):
        return int(obj)
    if isinstance(obj, (np.floating, np.float64, np.float32)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    if pd.isna(obj):
        return None
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

def clean_numeric_string(value: Any, is_percentage: bool = False) -> float:
    """Clean numeric strings with currency symbols, thousand separators, and percentage signs."""
    if pd.isna(value):
        return np.nan
    
    value_str = str(value).strip()
    
    # Remove common currency symbols and other non-numeric characters (except dots, commas, and percent)
    value_str = re.sub(r'[€$\s]', '', value_str)
    
    # Handle percentage: remove % sign and mark for division
    if is_percentage:
        value_str = value_str.replace('%', '')
    
    # Replace comma decimal with dot (contract says decimal=',')
    if ',' in value_str:
        # If there's a dot before comma (e.g., 1.000,50), dot is thousand separator
        if '.' in value_str and value_str.find('.') < value_str.find(','):
            # Remove dots (thousand separators) and replace comma with dot
            value_str = value_str.replace('.', '')
            value_str = value_str.replace(',', '.')
        else:
            # Just comma as decimal, replace with dot
            value_str = value_str.replace(',', '.')
    elif '.' in value_str:
        # Check if dot is thousand separator (more than one dot or pattern like 1.000)
        parts = value_str.split('.')
        if len(parts) > 2 or (len(parts) == 2 and len(parts[0]) > 3):
            # Dot is thousand separator, remove all dots
            value_str = value_str.replace('.', '')
    
    try:
        result = float(value_str)
        if is_percentage:
            # Convert percentage to decimal (e.g., 100% -> 1.0)
            result = result / 100.0
        return result
    except ValueError:
        return np.nan

def main():
    # Create output directories
    Path("data").mkdir(exist_ok=True)
    
    # Load data with contract dialect
    input_path = "data/raw.csv"
    df = pd.read_csv(
        input_path,
        sep=';',
        decimal=',',
        encoding='utf-8',
        dtype=str  # Load everything as string initially
    )
    
    print(f"Loaded {len(df)} rows, {len(df.columns)} columns")
    
    # Initialize manifest
    manifest = {
        "input_dialect": {"sep": ";", "decimal": ",", "encoding": "utf-8"},
        "output_dialect": {"sep": ",", "decimal": ".", "encoding": "utf-8"},
        "column_mapping": {},
        "dropped_columns": [],
        "conversions": {},
        "conversions_meta": {},
        "type_checks": {}
    }
    
    # Required columns from contract (canonical names)
    required_columns = [
        "CurrentPhase", "1stYearAmount", "Size", "Debtors", 
        "Sector", "Probability"
    ]
    
    # Check for missing required columns
    missing_cols = []
    for col in required_columns:
        if col not in df.columns:
            # Try case-insensitive match
            norm_map = {k.lower().replace(' ', ''): k for k in df.columns}
            norm_key = col.lower().replace(' ', '')
            if norm_key in norm_map:
                manifest["column_mapping"][col] = norm_map[norm_key]
                df[col] = df[norm_map[norm_key]]
            else:
                missing_cols.append(col)
    
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")
    
    # Clean each required column
    for col in required_columns:
        original_nulls = int(df[col].isna().sum())
        cleaned = df[col].copy()
        
        if col == "CurrentPhase":
            # Categorical - just clean whitespace
            cleaned = cleaned.str.strip()
            manifest["conversions"][col] = "categorical_whitespace_trim"
            
        elif col in ["1stYearAmount", "Size", "Debtors"]:
            # Numeric with currency/thousand separators
            cleaned = cleaned.apply(lambda x: clean_numeric_string(x, is_percentage=False))
            
            # Special handling for 1stYearAmount: 0 means "no offer" -> treat as missing
            if col == "1stYearAmount":
                cleaned_before_sentinel = cleaned.copy()
                cleaned = cleaned.replace(0, np.nan)
                sentinel_count = int((cleaned_before_sentinel == 0).sum())
                manifest["conversions_meta"][col] = {
                    "sentinel_0_count": sentinel_count,
                    "sentinel_action": "treat_as_missing"
                }
            
            manifest["conversions"][col] = "numeric_currency_clean"
            
        elif col == "Probability":
            # Percentage field
            # First handle nulls as 0 per business rule
            cleaned = cleaned.fillna("0")
            # Clean as percentage
            cleaned = cleaned.apply(lambda x: clean_numeric_string(x, is_percentage=True))
            # Ensure range 0-1
            cleaned = cleaned.clip(0, 1)
            manifest["conversions"][col] = "percentage_clean_null_to_0"
            
        elif col == "Sector":
            # Categorical - clean whitespace
            cleaned = cleaned.str.strip()
            cleaned = cleaned.replace({"": np.nan})
            manifest["conversions"][col] = "categorical_whitespace_trim"
        
        # Replace original column with cleaned values
        df[col] = cleaned
        
        # Record type check info
        nulls_after = int(df[col].isna().sum())
        filled_nulls = original_nulls if nulls_after < original_nulls else 0
        
        manifest["type_checks"][col] = {
            "original_nulls": original_nulls,
            "nulls_after": nulls_after,
            "filled_nulls": filled_nulls,
            "dtype": str(df[col].dtype),
            "unique_values": int(df[col].nunique()) if not df[col].isna().all() else 0
        }
    
    # Identify constant columns (all values identical) from the original dataset
    constant_cols = []
    for col in df.columns:
        if col not in required_columns and df[col].nunique(dropna=True) <= 1:
            constant_cols.append(col)
    
    # Drop constant columns (except required ones)
    if constant_cols:
        df = df.drop(columns=constant_cols)
        manifest["dropped_columns"].extend(constant_cols)
    
    # Save cleaned data
    output_path = "data/cleaned_data.csv"
    df.to_csv(output_path, index=False, sep=',', encoding='utf-8')
    print(f"Saved cleaned data to {output_path}")
    
    # Save manifest
    manifest_path = "data/cleaning_manifest.json"
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, default=_json_default)
    print(f"Saved manifest to {manifest_path}")
    
    # Print validation summary
    print("\n" + "="*60)
    print("CLEANING_VALIDATION")
    print("="*60)
    
    for col in required_columns:
        info = manifest["type_checks"][col]
        null_frac = info["nulls_after"] / len(df) if len(df) > 0 else 0
        
        print(f"\n{col}:")
        print(f"  dtype: {info['dtype']}")
        print(f"  nulls: {info['nulls_after']} ({null_frac:.1%})")
        print(f"  unique values: {info['unique_values']}")
        
        if df[col].dtype.kind in 'iuf':  # numeric
            non_null = df[col].dropna()
            if len(non_null) > 0:
                print(f"  range: [{non_null.min():.2f}, {non_null.max():.2f}]")
                print(f"  mean: {non_null.mean():.2f}")
        
        # Business rule specific checks
        if col == "1stYearAmount":
            sentinel_info = manifest["conversions_meta"].get(col, {})
            sentinel_count = sentinel_info.get("sentinel_0_count", 0)
            if sentinel_count > 0:
                print(f"  sentinel 0 values: {sentinel_count} (treated as missing)")
        
        if col == "Probability":
            zero_prob = int((df[col] == 0).sum())
            print(f"  zero probability values: {zero_prob}")

if __name__ == "__main__":
    main()